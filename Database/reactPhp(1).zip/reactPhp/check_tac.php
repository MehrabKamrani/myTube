<?php
include("DBconfig.php");
session_start();

//$con = new mysqli("localhost", "root", "", "mytube");

$json = file_get_contents('php://input');

$obj = json_decode($json,true);


$username = $_SESSION['username'];
//$username = 'Trtrtrtr';

$enteredTac = $obj['tac'];
//$enteredTac = '546140';

$sql = $con->query("SELECT TAC FROM member WHERE username = '$username'");
foreach ($sql as $key => $rst1) {
	$actualTac = $rst1["TAC"];
}
if ($enteredTac == $actualTac) {
	$sql = "UPDATE member SET isVerified=1 WHERE username='$username'";
	if ($con->query($sql) === TRUE) {
		$MSG = 'Congratulations! Your account has been activated!' ;
	}
		// Converting the message into JSON format.
	$json = json_encode($MSG);
		// Echo the message.
	echo $json ;
}

else
{
	$MSG = 'Fail';
		// Converting the message into JSON format.
	$json = json_encode($MSG);
		// Echo the message.
	echo $json ;
}




mysqli_close($con);
?>
