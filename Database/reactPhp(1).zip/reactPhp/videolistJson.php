<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
include ("DBconfig.php");

//$con = new mysqli("localhost", "root", "", "abc");

$result = $con->query("SELECT * from video where approve = 1 ORDER BY title ASC");

$outp = '[';
$aa=0;

while($rs = $result->fetch_array())
{
	if($aa > 0)
	{
		$outp .= ",";
	}
	
	$outp .= '{"VideoID":"'.$rs["videoID"].'",';
	$outp .= '"Title":"'.$rs["title"].'",';
	$outp .= '"Description":"'.$rs["description"].'",';
	$outp .= '"NumViews":"'.$rs["numViews"].'",';
	$outp .= '"VideoPath":"'.$rs["videoPath"].'"}';
	
	$aa = 1;
}
$con->close();

$outp .= ']';


echo($outp);
?>