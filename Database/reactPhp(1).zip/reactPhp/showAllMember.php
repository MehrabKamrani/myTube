<?php

// Create conection
include ("DBconfig.php");

if ($con->conect_error) {

 die("conection failed: " . $con->conect_error);
}

// Creating SQL command to fetch all records from Table.
$sql = "SELECT * FROM member";

$result = $con->query($sql);

if ($result->num_rows >0) {


 while($row[] = $result->fetch_assoc()) {

 $item = $row;

 $json = json_encode($item);

 }

} else {
 echo "No Results Found.";
}
 echo $json;
$con->close();
?>
