<?php 
// Create connection
include 'DBconfig.php';
$json = file_get_contents('php://input'); 
$obj = json_decode($json,true);
$videoID = $obj['videoID'];
//$videoID  = 'VID_5acf83206fce30.45816608';

 if(!empty($videoID)){
 	// Creating SQL command to fetch all records from Table.
	$sql = "SELECT numViews FROM video WHERE videoID = '$videoID'";	 
	$result = $con->query($sql);
	foreach($result as $key => $rst){
		$views = $rst['numViews'];
	}
	$totalV = $views + 1;
	$updateViews = "UPDATE video SET numViews = '$totalV' WHERE videoID = '$videoID'";
 	if($upRE = $con->query($updateViews)){
 		$item= 'Number of Views'.$totaleV;
 		echo $json = json_encode($item);
 	}else{
 		$itemF= 'failed';
 		echo $json = json_encode($itemF);
 	}
 }else{
 	$emp= 'video ID Is empty';
 	echo $json = json_encode($emp);
 } 
$con->close();
?>