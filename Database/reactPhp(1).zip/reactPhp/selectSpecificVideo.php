<?php 
// Create connection
include 'DBconfig.php';

$name = $_POST['videoTitle'];
//$name = 'Another';
 
// Creating SQL command to fetch all records from Table.
$sql = "SELECT * FROM video WHERE title = '$name' and approve = 1";
 
$result = $con->query($sql);
 
if ($result->num_rows >0) {
 
 
 while($row[] = $result->fetch_assoc()) {
 
 $item = $row;
 
 $json = json_encode($item);
 
 }
 echo $json;
 
} 
else {
 echo "No result";
}
 
$con->close();
?>