<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
include ("DBconfig.php");

//$con = new mysqli("localhost", "root", "", "abc");
$json = file_get_contents('php://input'); 
$obj = json_decode($json,true);
//$videoID = $obj['videoID'];

$videoID  = 'VID_5acf83206fce30.45816608';

$result = $con->query("SELECT * from video where videoID='$videoID'");

$outp = '[';
$aa=0;

while($rs = $result->fetch_array())
{
	if($aa > 0)
	{
		$outp .= ",";
	}
	
	$outp .= '{"VideoID":"'.$rs["videoID"].'",';
	$outp .= '"Title":"'.$rs["title"].'",';
	$outp .= '"Description":"'.$rs["description"].'",';
	$outp .= '"NumViews":"'.$rs["numViews"].'",';
	$outp .= '"VideoPath":"'.$rs["videoPath"].'"}';
	
	$aa = 1;
}
$con->close();

$outp .= ']';


echo($outp);
?>