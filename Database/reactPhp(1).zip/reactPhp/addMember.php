	<?php
	session_start();

// conecting to MySQL Database. tested ok with hard coded data
	include 'DBconfig.php';

 // Getting the received JSON into $json variable.
	$json = file_get_contents('php://input');

 // decoding the received JSON and store into $obj variable.
	$obj = json_decode($json,true);

	$fullname = $obj['userFullname'];

	$username = $obj['userName'];

	$email = $obj['userEmail'];

	$password = $obj['userPassword'];

	//generating random 6-digit number
	$tac = rand(100000, 999999);


	if (!empty($username) && !empty($password) && !empty($fullname) && !empty($email)) {


		$sql = "INSERT INTO member (fullname, username, email, password, TAC)
		VALUES ('$fullname', '$username', '$email', '$password', '$tac')";

	//Checking for duplicates
		$dupesql_admin_username = "SELECT * FROM admin where (username = '$username')";
		$dupesql_username = "SELECT * FROM member where (username = '$username')";
		$dupesql_email = "SELECT * FROM member where (email = '$email')";

		$duperaw_admin_username = $con->query($dupesql_admin_username);
		$duperaw_username = $con->query($dupesql_username);
		$duperaw_email = $con->query($dupesql_email);

		if (mysqli_num_rows($duperaw_username) > 0 || mysqli_num_rows($duperaw_admin_username) > 0) {
			$MSG = 'The username already exists' ;
		// Converting the message into JSON format.
			$json = json_encode($MSG);
		// Echo the message.
			echo $json ;
		}

		else if(mysqli_num_rows($duperaw_email) > 0){
			$MSG = 'The email already exists' ;
		// Converting the message into JSON format.
			$json = json_encode($MSG);
		// Echo the message.
			echo $json ;
		}

		else{

			if ($con->query($sql) === TRUE) {
				//I started session, as I wanted to use it in the next page
				$_SESSION['username'] = $username;
				$MSG = 'Registered successfully!' ;
				// Converting the message into JSON format.
				$json = json_encode($MSG);
				// Echo the message.
				echo $json ;
			} else {
				echo "Error: " . $sql . "<br>" . $con->error;
			}

		}

	}
	else{
		$MSG = 'Please, fill out the fields' ;
				// Converting the message into JSON format.
		$json = json_encode($MSG);
				// Echo the message.
		echo $json ;
	}


	$con->close();


	?>
