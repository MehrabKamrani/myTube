<?php
//Make con to database
include 'DBconfig.php';
session_start();


$videoID = uniqid("VID_", true);
$ProductName = $_POST['videoTitle'];
$ProductDes = $_POST['videoDescription'];
$logedInUser = $_SESSION['loginUsername'];

$target_dir = "videos/";
$target_file = $target_dir . basename($_FILES["video"]["name"]);
$uploadOk = 1;
$imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);

$ProductImage = basename($_FILES["video"]["name"]);
$message = 'E';

if ($uploadOk == 0) {
    $message =  "Sorry, your file was not uploaded.";
} else {
	if (move_uploaded_file($_FILES["video"]["tmp_name"], $target_file)) {
	        $message =  'AAA';			
		$query = "INSERT INTO video ( videoID, title, description, uploadedBy, videoPath) VALUES('$videoID','$ProductName','$ProductDes','$logedInUser', '$ProductImage')";	
			//Temporarily echo $query for debugging purposes
			$message= $query;
	
			//run $query
			mysqli_query($con, $query);
			if (mysqli_affected_rows($con) > 0) {
				$message= "Video Uploaded";
			} else {
				$message= "Error in query: $query. " . mysqli_error($con);
	
			}
	    } else {
	        $message= "ASAA, there was an error uploading your file.";
	    }
}
    $json = json_encode($message);
    echo $json ;
?>