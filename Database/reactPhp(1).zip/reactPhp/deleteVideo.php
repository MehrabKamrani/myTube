<?php
 
// Importing DBConfig.php file.
include 'DBconfig.php';
  
 // Getting the received JSON into $json variable.
 $json = file_get_contents('php://input');
 
 // decoding the received JSON and store into $obj variable.
 $obj = json_decode($json,true);
 
 $videoID = $obj['videoID'];
 //$id = 3;

 //Getting username
 	$get_username_sql = "SELECT uploadedBy, title FROM video WHERE videoID = '$videoID'";
 	$get_username_row = mysqli_query($con, $get_username_sql) or die(mysqli_error($con));
	$result = mysqli_fetch_assoc($get_username_row);
	$memberUsername = $result['uploadedBy'];
	$title = $result['title'];
	

	//Getting email
	$get_email_sql = "SELECT fullname, email FROM member WHERE username = '$memberUsername'";
 	$get_email_row = mysqli_query($con, $get_email_sql) or die(mysqli_error($con));
	$result = mysqli_fetch_assoc($get_email_row);
	$email = $result['email'];
	$fullname = $result['fullname'];

 	//echo $title;
	//echo $memberUsername;
 	//echo $email;
 	///echo $fullname;

 	// Prepare the message
	$message = "Dear $fullname,\r\n\r\nYour video \"$title\" has been deleted as it did not meet the requirements of the myTube";
	// In case any of our lines are larger than 70 characters, we should use wordwrap()
	$message = wordwrap($message, 70, "\r\n");
	//headers
	$headers = 'From: notreply@224tech.com' . "\r\n" . $email;
	//Send 
	mail($email, 'Video Deleted', $message, $headers);
 
 $Sql_Query = "DELETE FROM video WHERE videoID = '$videoID'" ;
 
 
 if(mysqli_query($con,$Sql_Query)){
 
$MSG = 'Deleted';
 
$json = json_encode($MSG);
 
 echo $json ;
 
 }
 else{
 	$MSG = 'Try again';
 	echo $MSG;
 
 }
 mysqli_close($con);
?>