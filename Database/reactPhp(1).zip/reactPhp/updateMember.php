<?php

// Connecting to MySQL Database. hard coded data tested ok
include 'DBconfig.php';

 // Getting the received JSON into $json variable.
 $json = file_get_contents('php://input');

 // decoding the received JSON and store into $obj variable.
 $obj = json_decode($json,true);

 // Populate Pokemon ID from JSON $obj array and store into $S_Name.
 $id = $obj['id'];
 //$id = 2;

 $username = $obj['username'];
 //$username = 'Zizou';

 // Populate Pokemon name from JSON $obj array and store into $S_Name.
 $fullname = $obj['fullname'];
 //$fullname = 'SomeoneElse';

 // Populate Pokemon Class from JSON $obj array and store into $S_Class.
 $email = $obj['email'];
 //$email = 'Mk.zizou@gmail.com';

 // Populate Student Phone Number from JSON $obj array and store into $S_Phone_Number.
 $password = $obj['password'];
 //$password = '123456';

 $isVerified = $obj['isVerified'];

if (!empty($username) && !empty($password) && !empty($fullname) && !empty($email)) {
  // Creating SQL query and insert the record into MySQL database table.
  $sql = "UPDATE member SET fullname= '$fullname', username = '$username', email = '$email', isVerified = '$isVerified', password = '$password' WHERE id = '$id'";
  //Checking for duplicates
	$dupesql_admin_username = "SELECT * FROM admin where (username = '$username')";
	$dupesql_username = "SELECT * FROM member where (username = '$username') AND id != '$id'";
	$dupesql_email = "SELECT * FROM member where email = '$email' AND id != '$id'";

	$duperaw_admin_username = $con->query($dupesql_admin_username);
	$duperaw_username = $con->query($dupesql_username);
	$duperaw_email = $con->query($dupesql_email);

	if (mysqli_num_rows($duperaw_username) > 0 || mysqli_num_rows($duperaw_admin_username) > 0) {
		$MSG = 'The username already exists' ;
	// Converting the message into JSON format.
		$json = json_encode($MSG);
	// Echo the message.
		echo $json ;
	}

	else if(mysqli_num_rows($duperaw_email) > 0){
		$MSG = 'The email already exists' ;
	// Converting the message into JSON format.
		$json = json_encode($MSG);
	// Echo the message.
		echo $json ;
	}

	else{

    if(mysqli_query($con,$sql)){
      // If the record inserted successfully then show the message.
      $MSG = 'Updated Successfully!' ;
      // Converting the message into JSON format.
      $json = json_encode($MSG);
      // Echo the message.
      echo $json ;
    }
    else{
      echo 'Try Again';
    }
  }

}	else{
  $MSG = 'Please, fill out the fields' ;
  		// Converting the message into JSON format.
  $json = json_encode($MSG);
  		// Echo the message.
  echo $json ;
}
 mysqli_close($con);
?>
