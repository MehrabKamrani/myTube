<?php
	//email function
	function emailTo( $email,$fullname,$tac){
		
		$to      = $email;
		$subject = "MyTube Account Activation";
		$message = "Hello: \r\n\r\nDear\r\n\r\n" . $fullname . "\r\n\r\nThank you for using MyTube APP .\r\n\r\n The Following are your TAC code:\r\n\r\TAC: " .$tac."\r\n\r\n Please use it to activate your account.\r\n\r\n Note: This is computer generated email. DO NOT REPLY TO THIS EMAIL.";
		$headers = 'From: notreply@224tech.com'. "\r\n" .$email;
		
		$mail = mail($to,  $subject, $message,  $headers);
		/*if($mail){
			$json = json_encode('Done');
			echo $json;
		}else{
			
			$json = json_encode('Failded');
			echo $json;
		}*/
	}
?>