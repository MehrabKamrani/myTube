<?php
 
include 'DBconfig.php';
  
 $json = file_get_contents('php://input');
 
 $obj = json_decode($json,true);
 
 $id = $obj['videoID'];
 //$id = 'VID_000000002';
 
 //To validate to empty input ID. Because with empty ID it works as well. Needs to check it
 $Sql_Query = "SELECT videoID from video WHERE videoID = '$id'";
 $result = $con->query($Sql_Query);
 
 if($result->num_rows >0){
 	
 	$approve_sql = "UPDATE video SET approve = 2 WHERE videoID = '$id'";
 	$con->query($approve_sql);

 	//Getting username
 	$get_username_sql = "SELECT uploadedBy, title FROM video WHERE videoID = '$id'";
 	$get_username_row = mysqli_query($con, $get_username_sql) or die(mysqli_error($con));
	$result = mysqli_fetch_assoc($get_username_row);
	$memberUsername = $result['uploadedBy'];
	$title = $result['title'];
	

	//Getting email
	$get_email_sql = "SELECT fullname, email FROM member WHERE username = '$memberUsername'";
 	$get_email_row = mysqli_query($con, $get_email_sql) or die(mysqli_error($con));
	$result = mysqli_fetch_assoc($get_email_row);
	$email = $result['email'];
	$fullname = $result['fullname'];

 	
 	//echo $title;
	//echo $memberUsername;
 	//echo $email;
 	///echo $fullname;

 	// Prepare the message
	$message = "Dear $fullname,\r\n\r\nYour video \"$title\" has been rejected";
	// In case any of our lines are larger than 70 characters, we should use wordwrap()
	$message = wordwrap($message, 70, "\r\n");
	//headers
	$headers = 'From: notreply@224tech.com' . "\r\n" . $email;
	//Send 
	mail($email, 'Video Rejection', $message, $headers);

 	$MSG = 'Success' ;
	$json = json_encode($MSG);
	echo $json ;
 }
 else{
 
 	echo 'Try Again';
 
 }
 	mysqli_close($con);
?>