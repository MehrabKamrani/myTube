import React, { Component }  from 'react';
import { Text, TextInput, View, Button, Alert, StyleSheet } from 'react-native';
import Hyperlink from 'react-native-hyperlink'


export default class signUp extends Component{

}
